# Zip holiday-calendar plugin after agent session ends (Cursor stop hook).
# Bumps patch version in holiday-calendar.php and readme.txt before zipping.
$ErrorActionPreference = 'Stop'

$ProjectRoot  = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$PluginFolder = Split-Path $ProjectRoot -Leaf
$MainFile     = Join-Path $ProjectRoot 'holiday-calendar.php'
$ReadmeFile   = Join-Path $ProjectRoot 'readme.txt'
$ZipPath      = Join-Path (Split-Path $ProjectRoot -Parent) 'holiday-calendar.zip'
$Exclude      = @('.git', '.cursor', 'node_modules', 'vendor')

function Get-PluginVersionFromHeader {
    param([string]$Path)
    $line = Select-String -Path $Path -Pattern '^\s*\*\s*Version:\s*(.+)$' | Select-Object -First 1
    if (-not $line) {
        throw "Could not find Version in plugin header: $Path"
    }
    $version = $line.Matches.Groups[1].Value.Trim()
    if ($version -notmatch '^\d+\.\d+\.\d+$') {
        throw "Unsupported version format (expected semver x.y.z): $version"
    }
    return $version
}

function Get-SemverPatchBump {
    param([string]$Version)
    $parts = $Version.Split('.')
    $major = [int]$parts[0]
    $minor = [int]$parts[1]
    $patch = [int]$parts[2] + 1
    return "$major.$minor.$patch"
}

function Set-PluginVersionEverywhere {
    param(
        [string]$Root,
        [string]$NewVersion
    )
    $main = Join-Path $Root 'holiday-calendar.php'
    $readme = Join-Path $Root 'readme.txt'

    $mainContent = [System.IO.File]::ReadAllText($main)
    $mainContent = [regex]::Replace(
        $mainContent,
        '(?m)^(\s*\*\s*Version:\s*)\S+',
        "`${1}$NewVersion"
    )
    $mainContent = [regex]::Replace(
        $mainContent,
        "define\(\s*'HC_VERSION',\s*'[^']+'\s*\)",
        "define( 'HC_VERSION', '$NewVersion' )"
    )
    [System.IO.File]::WriteAllText($main, $mainContent)

    $readmeContent = [System.IO.File]::ReadAllText($readme)
    $readmeContent = [regex]::Replace(
        $readmeContent,
        '(?m)^Stable tag:\s*\S+',
        "Stable tag: $NewVersion"
    )
    [System.IO.File]::WriteAllText($readme, $readmeContent)
}

$currentVersion = Get-PluginVersionFromHeader -Path $MainFile
$newVersion     = Get-SemverPatchBump -Version $currentVersion
Set-PluginVersionEverywhere -Root $ProjectRoot -NewVersion $newVersion
Write-Host "Version bumped: $currentVersion -> $newVersion"

$stagingDir    = Join-Path $env:TEMP ("hc-zip-" + [guid]::NewGuid().ToString('n'))
$stagingPlugin = Join-Path $stagingDir $PluginFolder

try {
    New-Item -ItemType Directory -Path $stagingPlugin -Force | Out-Null

    Get-ChildItem -Path $ProjectRoot -Force |
        Where-Object { $Exclude -notcontains $_.Name } |
        ForEach-Object {
            Copy-Item -Path $_.FullName -Destination $stagingPlugin -Recurse -Force
        }

    if (Test-Path $ZipPath) {
        Remove-Item $ZipPath -Force
    }

    # Compress the plugin folder itself so zip root is holiday-calendar/ (matches Windows Explorer).
    Compress-Archive -Path $stagingPlugin -DestinationPath $ZipPath -CompressionLevel Optimal
    $zipSize = (Get-Item $ZipPath).Length
    Write-Host "Created: $ZipPath ($zipSize bytes)"
}
finally {
    if (Test-Path $stagingDir) {
        Remove-Item $stagingDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

exit 0
